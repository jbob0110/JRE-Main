# jresubs
Firefox add-on to create JIRA sub-subtask with default Assignee/Summary/Description/Labels

SC-Y Button adds sub-tasks and labels in JIRA

Sub-tasks are assigned to the appropriate SD (Requirement Sub-task), TA (Test Case/Senario Review Sub-task), and SE (Grey Box AND Automation Sub-Tasks selected in the dropdowns

Options Button takes you to the options page where you can edit the SD, TA, and SE that show in the pop-up dropdown lists.

Release Notes Button adds a single sub-task for the SD selected (Release Notes Sub-task)

SC-Y AND Release Notes Button will still create JIRAs if and SD, TA, or SE is NOT selected.
Sub-task assignment will default to what is set in your JIRA Options